package sujet0.lanceur;

import sujet0.controleur.Controleur;

/**
 * Lanceur du sujet 0
 * @author amélie nioche hugo labbé, yann reibel, clément jeanne dit fouque, louis-pierre aubert
 * */
public class Main {

	public static void main(String[] args) {
		Controleur ctrl = new Controleur();
		ctrl.init();
	}
}
