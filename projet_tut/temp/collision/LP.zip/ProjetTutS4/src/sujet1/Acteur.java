package sujet1;

public interface Acteur {
	
	public abstract void deplacer ();
	public double getMasse ();
	
}
