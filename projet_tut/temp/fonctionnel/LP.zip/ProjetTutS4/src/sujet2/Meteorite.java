package sujet2;

import java.awt.Dimension;

import sujet1.Acteur;
import sujet1.Coordonnees;
import sujet1.Fusee;
import sujet1.Sprite;
import sujet1.Vecteur;
import sujet1.metier.plateau.Plateau;

public class Meteorite extends Sprite implements Acteur {
	
	/** Masse en kg */
	public static final double MASSE = 1000;
	
	// VTS = VITESSE en px/s
	public static final double MAX_VTS = 0.100;  // 100px/s
	public static final double MIN_VTS = 0.0001; // à l'arret si inferieur
	
	// CELERATION en px/s²
	public static final double ACCELERATION = 0.001;
	public static final double DECELERATION = 0.000000001;
	
	public static final int INCREMENT_ROT = 5;
	
	// Modificateurs de vitesses
	public static final double POUSSEE                = 30;
	public static final double INTENSITE_ACCELERATION = 1;
	
	// DGR = DEGREE
	public static final int MAX_DGR = 360;
	public static final int MIN_DGR =   0;
	
	private double  acceleration;
	private double  vitesse;
	private Vecteur vecteur;
	
	/** On applique, à cette instance de cette classe,une accélération et un angle aléatoire.
	 *  L'accélération varie entre 0.01 et 0.2 pixel/ms.
	 *  La direction varie entre 0 et 360°;
	 * @param img
	 *           Chemin de l'image.
	 * @param posX
	 *           Position initiale X.
	 * @param posY 
	 *           Position initiale Y.
	 * @param largeur
	 *           Largeur.
	 * @param hauteur
	 *           Hauteur.
	 */
	public Meteorite ( Plateau p, String img, double posX, double posY, int diametre ) {
		super(p, img, new Coordonnees(posX,posY), new Dimension(diametre,diametre) );
		this.acceleration = Math.random()*0.02 + 0.01;
		this.rot          = (int)( Math.random()*360) ;
		this.vitesse      = MIN_VTS;
		this.vecteur      = new Vecteur(MIN_VTS,MIN_VTS);
	}
		
	/** Applique les forces sur la météorite. Doit être appellé par un Thread.
	 */
	@Override
	public void deplacer () {
		
		Sprite objetTouche = this.verifierColisions();
		//System.out.println("Météorie: Objet touché : "+objetTouche);
		this.enColision = objetTouche != null;
		
		if ( this.enColision && !(objetTouche instanceof Fusee) ) {
			this.calculChocs( (Meteorite)objetTouche );
		} else {
			this.vecteur.setForceX( this.vecteur.forceX + POUSSEE * this.acceleration *  Math.sin( Math.toRadians(this.rot) ) );
			this.vecteur.setForceY( this.vecteur.forceY + POUSSEE * this.acceleration * -Math.cos( Math.toRadians(this.rot) ) );
			
			this.pos.setX( this.pos.getX()+ this.vecteur.forceX );
			this.pos.setY( this.pos.getY()+ this.vecteur.forceY );
			
			if      (  this.vecteur.forceX >  POUSSEE*MAX_VTS ) this.vecteur.forceX =  POUSSEE*MAX_VTS;
			else if (  this.vecteur.forceX < -POUSSEE*MAX_VTS ) this.vecteur.forceX = -POUSSEE*MAX_VTS;
			if      (  this.vecteur.forceY >  POUSSEE*MAX_VTS ) this.vecteur.forceY =  POUSSEE*MAX_VTS;
			else if (  this.vecteur.forceY < -POUSSEE*MAX_VTS ) this.vecteur.forceY = -POUSSEE*MAX_VTS;
			
			this.pos = this.deplacementTorique(this.pos);
				
			this.vitesse = this.calcVitesse();
		}
	}
	
	private void calculChocs ( Meteorite objetTouche ) {
		double  m1 = this.getMasse();
		double  m2 = objetTouche.getMasse();
		Vecteur v1 = this.vecteur;
		Vecteur v2 = objetTouche.vecteur;
		
		
		
		//(1/2)* objetTouche.getMasse()
		
	}
	
	public Vecteur getVecteur () { return this.vecteur; }

	@Override
	public double getMasse() { return MASSE; }
		
	/** Calcul la vitesse en fonction des vecteurs.
	 * @return La vitesse de la fusée.
	 */
	private double calcVitesse () {
		return Math.sqrt( this.vecteur.forceX*this.vecteur.forceX + this.vecteur.forceY*this.vecteur.forceY );
	}
		
	/** Pivote la météorite en fonction de la caractère passée en paramètre.
	 * @param sens
	 *        + : Rotation horaire
	 *        - : Rotation anti-horaire
	 */
	@Override
	public void rotation ( char sens ) {
		int val = 0;
		
		if ( sens == '+' )
			val = this.rot + INCREMENT_ROT; // Sens horaire
		else
			val = this.rot - INCREMENT_ROT; // Sans anti-horaire
	
		if ( val > MAX_DGR )
			this.rot = MIN_DGR;
		else if ( val < MIN_DGR )
			this.rot = MAX_DGR;
		else
			this.rot = val;			
		}
		
	/** Affiche les données des attributs de la météorite.
	 */
	public String toString () {
		String message = "Météorite: Pos[%4.3f;%4.3f] Rot[%3d] Accélération[%3f] Vitesse[%4.3f] Vecteur[%4.3f;%4.3f] Colision[%b]";
		return String.format(message, this.pos.getX(), this.pos.getY(), this.rot, this.acceleration,
				                      this.vitesse, this.vecteur.forceX, this.vecteur.forceY, this.enColision );
	}
}
