package beans;

import java.util.*;

public class Utilisateur{
	private int idu;
    private String nom;
    private String role;

   	public int getIdu(){return idu;}
    public String getNom(){return nom;}
    public String getRole(){return role;}
    
    public void setIdu(int idu){this.idu = idu;}
    public void setNom(String nom){ this.nom = nom;   }
    public void setRole(String role){this.role = role;}
        
	public Utilisateur(int idu , String nom, String role){
		this.setIdu(idu);
		this.setNom(nom);
	    this.setRole(role);
    }

	public Utilisateur(String nom, String role){
	    this.setIdu(-1);
	    this.setNom(nom);
	    this.setRole(role);
   	}

	public String toString(){
   		return idu + "," + nom + "," + role;
	}
}

