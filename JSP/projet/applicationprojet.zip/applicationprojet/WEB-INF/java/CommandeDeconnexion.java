package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CommandeDeconnexion implements Commande {
	private String next;

	public CommandeDeconnexion(String next){
		this.next = next;
	}

	public String execute(HttpServletRequest req) throws Exception {
		String cible = next;


		HttpSession session = req.getSession(true); 
		session.invalidate(); // On détruit la session

		return cible;
	}

}
