package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_UTILISATEUR;
import beans.Utilisateur;

public class CommandeModifierUtilisateurs implements Commande {
  private final String next;

  public CommandeModifierUtilisateurs(String next) {
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_UTILISATEUR dbUtilisateur = dbGlobal.getDB_UTILISATEUR();
	Utilisateur utilisateur = null;
	int idu = Integer.parseInt(req.getParameter("idu")); 


	/* On affiche l'utilisateur en cours */
	try{
		utilisateur = dbUtilisateur.getUtilisateur(idu);
	}

	catch(Exception e){
		System.out.println(e);
	}

	req.setAttribute("utilisateur", utilisateur);
    return next;
  }
}
