import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.lang.reflect.Constructor;
import cmd.Droits;

public class ControleSession extends HttpServlet {
	
	private void forwardJSP(HttpServletRequest req, HttpServletResponse res,String pageJSP) throws ServletException, IOException {
		req.setAttribute("forwardOK",true);
		RequestDispatcher dispatcher = req.getRequestDispatcher(pageJSP);
		dispatcher.forward(req, res);
	}

	
	private Integer getDroitSession(HttpServletRequest req) {
		Integer droitUtil = 0;

		/* REMPLI */
		HttpSession session = req.getSession(false);
		droitUtil = (Integer)session.getAttribute("droitsAcces");
		/* REMPLI */

		return droitUtil;
	}

	private boolean evaluerDroitCommande(HttpServletRequest req) {
		boolean droitCommande = false;

		/* On verifie les droits */
		droitCommande = req.getAttribute("droitCmd").equals(Droits.DROIT_PAGE_ADMIN);
		/* Verification */
		return droitCommande;
	}


	public void service(HttpServletRequest req, HttpServletResponse res) 
		throws ServletException, IOException { 

		Integer droitUtil = getDroitSession(req);
		
		if (droitUtil == null){	
			forwardJSP(req,res, "/login.jsp");
		}

		else{
			boolean droitAdmin = evaluerDroitCommande(req);
			if (droitAdmin){
				if (droitUtil != Droits.DROIT_UTIL_ADMIN) {
					forwardJSP(req,res,Controleur.JSP_ERREUR_DROIT);
				}
			} 
		} 
	}
} 
