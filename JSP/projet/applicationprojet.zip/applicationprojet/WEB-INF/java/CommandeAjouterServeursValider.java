package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_SERVEUR;
import beans.Serveur;


public class CommandeAjouterServeursValider implements Commande {
  private final String next;

  public CommandeAjouterServeursValider(String next) {
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_SERVEUR dbServeur = dbGlobal.getDB_SERVEUR();
	List<Serveur> serveurs = null;
	String nom = req.getParameter("nom");
	String os = req.getParameter("os");
	Serveur serveur = new Serveur(nom, os);


	/* Ajoute le serveur en fonction des informations du formulaire récupérées sur l'url */
	try{
		dbServeur.insertServeur(serveur);
	}

	catch(Exception e){
		System.out.println(e);
	}

	try{
		serveurs = dbServeur.getServeurs();
	}

	catch(Exception e){
		System.out.println(e);
	}

	req.setAttribute("serveurs", serveurs);
    return next;
  }

}
