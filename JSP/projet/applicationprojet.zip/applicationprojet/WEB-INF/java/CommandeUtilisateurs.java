package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_UTILISATEUR;
import beans.Utilisateur;

public class CommandeUtilisateurs implements Commande{
  private final String next;

  public CommandeUtilisateurs(String next){
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception{
	DBS dbGlobal = DBS.getInstance();
	DB_UTILISATEUR dbUtilisateur = dbGlobal.getDB_UTILISATEUR();
	List<Utilisateur> utilisateurs = null;
	String tri = req.getParameter("tri");


	/* On affiche les utilisateurs, soit par tri */
	if (tri != null ){
		try{
			utilisateurs = dbUtilisateur.getUtilisateursTri(tri);
		}

		catch(Exception e){
			System.out.println(e);
		}
	}

	/* Ou normalement */
	else {
		try{
			utilisateurs = dbUtilisateur.getUtilisateurs();
		}

		catch(Exception e){
			System.out.println(e);
		}
	}

	req.setAttribute("utilisateurs", utilisateurs);
    return next;
  }

}
