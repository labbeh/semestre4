package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_UTILISATEUR;
import beans.Utilisateur;


public class CommandeModifierUtilisateurValider implements Commande {
  private final String next;

  public CommandeModifierUtilisateurValider(String next) {
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_UTILISATEUR dbUtilisateur = dbGlobal.getDB_UTILISATEUR();
	List<Utilisateur> utilisateurs = null;

	/* On crée un utilisateur en fonction du formulaire et on appel une méthode de DB_UTILISATEUR */
	try{
		int idu = Integer.parseInt(req.getParameter("idu")); 
		String nom = req.getParameter("nom");
		String role = req.getParameter("role");
		Utilisateur utilisateur = new Utilisateur(idu, nom, role);
		dbUtilisateur.updateUtilisateur(utilisateur);
	}

	catch(Exception e){
		System.out.println(e);
	}

	/* On recupère */
	try{
		utilisateurs = dbUtilisateur.getUtilisateurs();
	}

	catch(Exception e){
		System.out.println(e);
	}

	/* On affiche */
	req.setAttribute("utilisateurs", utilisateurs);
    return next;
  }

}
