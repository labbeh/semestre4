package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bdd.DBS;
import bdd.DB_SERVEUR;
import beans.Serveur;

public class CommandeServeurs implements Commande{
  private final String next;

  public CommandeServeurs(String next){
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception{
	DBS dbGlobal = DBS.getInstance();
	DB_SERVEUR dbServeur = dbGlobal.getDB_SERVEUR();
	List<Serveur> serveurs = null;
	String tri = req.getParameter("tri");


	/* On affiche les serveurs, trier */
	if (tri != null ){
		try{
			serveurs = dbServeur.getServeursTri(tri);
		}

		catch(Exception e){
			System.out.println(e);
		}
	}

	/* Ou non */
	else{
		try{
			serveurs = dbServeur.getServeurs();
		}

		catch(Exception e){
			System.out.println(e);
		}
	}
	req.setAttribute("serveurs", serveurs);
    return next;
  }
}
