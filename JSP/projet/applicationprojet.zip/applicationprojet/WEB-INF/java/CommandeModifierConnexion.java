package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_CONNEXION;
import beans.Connexion;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.sql.*;
import java.util.Date;

public class CommandeModifierConnexion implements Commande {
  private final String next;

  public CommandeModifierConnexion(String next) {
        this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_CONNEXION dbConnexion = dbGlobal.getDB_CONNEXION();
	Connexion connexion = null;
	int idu = Integer.parseInt(req.getParameter("idu"));
	int ids = Integer.parseInt(req.getParameter("ids")); 

	/* Gestion de la date */
	String datec = req.getParameter("datec");
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
	Date date = dateFormat.parse(datec);
	long time = date.getTime();
	Timestamp temps = new Timestamp(time);


	/* Donne les connexions en fonctions de l'id de l'utilisateur, serveur et du temps */
	try{
		connexion = dbConnexion.getConnexion(idu, ids, temps);
	}

	catch(Exception e){
		System.out.println(e);
	}

	req.setAttribute("connexion", connexion);
    return next;
  }

}
