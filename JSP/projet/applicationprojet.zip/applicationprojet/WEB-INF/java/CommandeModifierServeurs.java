package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_SERVEUR;
import beans.Serveur;


public class CommandeModifierServeurs implements Commande {
  private final String next;

  public CommandeModifierServeurs(String next) {
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_SERVEUR dbServeur = dbGlobal.getDB_SERVEUR();
	Serveur serveur = null;
	int ids = Integer.parseInt(req.getParameter("ids"));

	/* On recupère le serveur en fonction d'une id */

	try{
		serveur = dbServeur.getServeur(ids);
	}

	catch(Exception e){
		System.out.println(e);
	}

	req.setAttribute("serveur", serveur);
    return next;
  }

}
