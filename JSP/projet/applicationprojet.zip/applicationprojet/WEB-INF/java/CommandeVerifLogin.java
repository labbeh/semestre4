/* Class qui gère la connexion */

package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CommandeVerifLogin implements Commande {
	private String next;

	public CommandeVerifLogin(String next) {
		this.next = next;
	}

	public String execute(HttpServletRequest req) throws Exception{
	
		String cible = next;

		/* On recupère les paramètres du login */
		String nom = req.getParameter("nom");
		String pass = req.getParameter("pass");


		/* On vérifie s'ils sont sembables à la classe droits */
		if (nom.equals("user") && pass.equals("userpwd")){

			/* Si oui on crée une session qui donne les droits user */
    	    HttpSession session = req.getSession(true);
			session.setAttribute("droitsAcces", 1);
    	}

    	else{
      		if (nom.equals("admin") && pass.equals("adminpwd")){
      			/* Si oui on crée une session qui donne les droits admin */
      			HttpSession session = req.getSession(true);
				session.setAttribute("droitsAcces", 2);
      		}

      		else{
      			cible = "login.jsp";
      			req.setAttribute("erreurLogin", "LES IDENTIFIANTS SONT INCORRECTS !");
      		}
      	}
      	return cible;
	}
}
