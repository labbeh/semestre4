package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DB_UTILISATEUR;
import bdd.DB_CONNEXION;
import bdd.DBS;
import beans.Utilisateur;

public class CommandeSupprimerUtilisateur implements Commande{
  private final String next;

  public CommandeSupprimerUtilisateur(String next){
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception{
	DBS dbGlobal = DBS.getInstance();
	DB_UTILISATEUR dbUtilisateur = dbGlobal.getDB_UTILISATEUR();
	DB_CONNEXION dbConnexion = dbGlobal.getDB_CONNEXION();
	List<Utilisateur> utilisateurs = null;
	int idu = Integer.parseInt(req.getParameter("idu")); 

	/* On appel les méthodes de la base de données pour supprimer en fonction de l'id de l'utilisateur */
	try{
		/* Pour que ce soit safe, on enlève aussi la clé de la connexion */
		dbConnexion.deleteConnexionUtilisateur(idu);
		dbUtilisateur.deleteUtilisateur(idu);
	}

	catch(Exception e){
		System.out.println(e);
	}

	try{
		utilisateurs = dbUtilisateur.getUtilisateurs();
	}

	catch(Exception e){
		System.out.println(e);
	}

	req.setAttribute("utilisateurs", utilisateurs);
    return next;
  }

}
