package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_SERVEUR;
import bdd.DB_CONNEXION;
import beans.Serveur;


public class CommandeSupprimerServeur implements Commande {
  private final String next;

  public CommandeSupprimerServeur(String next) {
        this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_SERVEUR dbServeur = dbGlobal.getDB_SERVEUR();
	DB_CONNEXION dbConnexion = dbGlobal.getDB_CONNEXION();
	int ids = Integer.parseInt(req.getParameter("ids")); 
	List<Serveur> serveurs = null;

	/* On supprime le serveur en fonction d'une id de serveur et on enlève la connexion */
	try{
		dbConnexion.deleteConnexionServeur(ids);
		dbServeur.deleteServeur(ids);
	}

	catch(Exception e){
		System.out.println(e);
	}

	try{
		serveurs = dbServeur.getServeurs();
	}

	catch(Exception e){
		System.out.println(e);
	}

	req.setAttribute("serveurs", serveurs);
    return next;
  }

}
