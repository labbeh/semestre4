package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_CONNEXION;
import beans.Connexion;
import beans.ConnexionUS;

public class CommandeServeursUtilisateur implements Commande{
  private final String next;

  public CommandeServeursUtilisateur(String next){
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception{
	DBS dbGlobal = DBS.getInstance();
	DB_CONNEXION dbConnexion = dbGlobal.getDB_CONNEXION();
	int idu = Integer.parseInt(req.getParameter("idu"));
	List<ConnexionUS> connexions = null;

	/* On retourne les connexions en fonction de l'id d'un utilisateur de la classe DB_CONNEXION */
	try{
		connexions = dbConnexion.getConnexionsUtilisateur(idu);
	}

	catch(Exception e){
		System.out.println(e);}
	
	req.setAttribute("connexions", connexions);
    return next;
  }

}
