package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bdd.DBS;
import bdd.DB_CONNEXION;
import beans.ConnexionUS;
import beans.Connexion;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.sql.*;
import java.util.Date;

public class CommandeRechercher implements Commande{
  private final String next;

  public CommandeRechercher(String next) {
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_CONNEXION dbConnexion = dbGlobal.getDB_CONNEXION();
	List<ConnexionUS> connexions = null;
	int ids = Integer.parseInt(req.getParameter("serveur"));
	String date = req.getParameter("date");

	/* Transformation de la date */
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	Date dateF = dateFormat.parse(date);
	long duree = dateF.getTime();

	Timestamp y = new Timestamp(duree);
	long x = y.getTime() + (1000*60*60*24);
	Timestamp e = new Timestamp(x);

	/* Donne les connexions en fonction d'une date */
	try{
		connexions = dbConnexion.getConnexionsDateServeur(ids, dureeMinimum, dureeMaximum);
	}

	catch(Exception e){
		System.out.println(e);
	}
	
	req.setAttribute("connexions", connexions);
    return next;
  }

}
