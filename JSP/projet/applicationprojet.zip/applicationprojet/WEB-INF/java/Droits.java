/* Pour connaître les droits admin lors de la connexion et affichage du menu */

package cmd;

public abstract class Droits{

	public static final String LOGIN_ADMIN = "admin";
	public static final String MDP_ADMIN = "adminpwd";

	public static final String LOGIN_USER = "user";
	public static final String MDP_USER = "userpwd";

    public static final String DROIT_PAGE_ALL = "all";
    public static final String DROIT_PAGE_ADMIN = "admin";

	public static final int DROIT_UTIL_CONSULT = 1;
	public static final int DROIT_UTIL_ADMIN = 2;

	private Droits(){

	}
}
