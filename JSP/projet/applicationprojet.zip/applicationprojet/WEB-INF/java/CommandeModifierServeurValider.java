package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_SERVEUR;
import beans.Serveur;


public class CommandeModifierServeurValider implements Commande {
  private final String next;

  public CommandeModifierServeurValider(String next) {
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_SERVEUR dbServeur = dbGlobal.getDB_SERVEUR();
	List<Serveur> serveurs = null;

	/* En fonction des informations du formulaire, on modifie le serveur */
	try{
		int ids = Integer.parseInt(req.getParameter("ids")); 
		String nom = req.getParameter("nom");
		String os = req.getParameter("os");
		Serveur serveur = new Serveur(ids, nom, os);
		dbServeur.updateServeur(serveur);
	}

	catch(Exception e){
		System.out.println(e);
	}

	try{
		serveurs = dbServeur.getServeurs();
	}

	catch(Exception e){
		System.out.println(e);
	}

	req.setAttribute("serveurs", serveurs);
    return next;
  }
}
