/* Class développée en s'aidant du modèle de l'utilisateur */

package bdd;

import java.sql.*;
import java.util.*;
import beans.Serveur;

public class DB_SERVEUR {

  Connection conn;
  PreparedStatement ps_select;
  PreparedStatement ps_insert;
  PreparedStatement ps_update;
  PreparedStatement ps_delete;

  public DB_SERVEUR(Connection conn) {
     this.conn = conn;

     try{
        /* On prépare les requêtes */
        ps_select = conn.prepareStatement("select nom,os from serveur where ids=?");
  		  ps_insert = conn.prepareStatement("insert into serveur values(default,?,?)",PreparedStatement.RETURN_GENERATED_KEYS);
        ps_update = conn.prepareStatement("update serveur set nom=?, os=? where ids=?");
        ps_delete = conn.prepareStatement("delete from serveur where ids=?"); 
     }

     catch(SQLException ex){
      System.out.println(ex);
    }
  }
      
  /* Retourne un serveur en fonction de son id */
  public Serveur getServeur(int ids) throws Exception{
      Serveur s = null;
      ps_select.setInt(1, ids);
      ResultSet rs = ps_select.executeQuery();

      if(rs.next()){
    	  String nom = rs.getString("nom");
    	  String os = rs.getString("os");
        s = new Serveur(ids, nom, os);        
      }

      return s;
  }

  /* On insère un serveur selon des informations du formulaire */
  public int insertServeur(Serveur s) throws Exception{
			int clef = -1;
			ps_insert.setString(1,s.getNom());
			ps_insert.setString(2,s.getOS());
			ps_insert.executeUpdate();
			ResultSet clefs = ps_insert.getGeneratedKeys();
			if (clefs.next()){
			    clef = clefs.getInt(1);
			}
			return clef;
  }
        
  /* On modifie le serveur selon des informations du formulaire */
  public void updateServeur(Serveur s) throws Exception{
			ps_update.setString(1, s.getNom());
			ps_update.setString(2, s.getOS());
			ps_update.setInt(3, s.getIds());
			ps_update.executeUpdate();
  }

  /* On supprime le serveur selon une id récupérer en url */
  public void deleteServeur(int ids) throws Exception{
		  ps_delete.setInt(1,ids);
		  ps_delete.executeUpdate();
  }

  /* On retourne la globalité des serveurs dans un AL */
  private ArrayList<Serveur> getServeurs(String req) throws Exception{
      Serveur serv;
	    ArrayList<Serveur> arrserveur = new ArrayList<Serveur>();
		  Statement st = conn.createStatement(); 
		  ResultSet rs = st.executeQuery(req); 

		  while(rs.next()){ 
		      serv = new Serveur(rs.getInt("ids"), rs.getString("nom"), rs.getString("os")); 
		      arrserveur.add(serv); 
		  }

	    return arrserveur;
  }

  public ArrayList<Serveur> getServeurs() throws Exception{
	   return getServeurs("select * from serveur");
  }
  
  public ArrayList<Serveur> getServeursTri(String tri) throws Exception{
	   return getServeurs("select * from serveur order by " + tri);
  }
}
