package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_UTILISATEUR;
import beans.Utilisateur;


public class CommandeAjouterUtilisateursValider implements Commande {
  private final String next;

  public CommandeAjouterUtilisateursValider(String next) {
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_UTILISATEUR dbUtilisateur = dbGlobal.getDB_UTILISATEUR();
	List<Utilisateur> utilisateurs = null;
	String nom = req.getParameter("nom");
	String role = req.getParameter("role");
	Utilisateur utilisateur = new Utilisateur(nom, role);

	/* Ajoute l'utilisateur en fonction des informations du formulaire récupérées sur l'url */
	try{
		dbUtilisateur.insertUtilisateur(utilisateur);
	}

	catch(Exception e){
		System.out.println(e);
	}

	try{
		utilisateurs = dbUtilisateur.getUtilisateurs();
	}

	catch(Exception e){
		System.out.println(e);
	}

	req.setAttribute("utilisateurs", utilisateurs);
    return next;
  }

}
