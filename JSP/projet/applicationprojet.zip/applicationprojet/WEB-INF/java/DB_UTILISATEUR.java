/* Class donnée par l'enseignant pour voir le fonctionnement d'un utilisateur */

package bdd;

import java.sql.*;
import java.util.*;
import beans.Utilisateur;

public class DB_UTILISATEUR{

  Connection conn;
  PreparedStatement ps_select;
  PreparedStatement ps_insert;
  PreparedStatement ps_update;
  PreparedStatement ps_delete;

  public DB_UTILISATEUR(Connection conn){
     this.conn = conn;
     try{
        /* On prépare les requêtes */
        ps_select = conn.prepareStatement("select nom,role from utilisateur where idu=?");
  	    ps_insert = conn.prepareStatement("insert into utilisateur values(default,?,?)", PreparedStatement.RETURN_GENERATED_KEYS);
        ps_update = conn.prepareStatement("update utilisateur set nom = ?, role = ? where idu=?");
        ps_delete = conn.prepareStatement("delete from utilisateur where idu=?"); 
     }

     catch(SQLException ex){
      System.out.println(ex);
    }
  }
      
  public Utilisateur getUtilisateur(int idu) throws Exception{
    
      Utilisateur u = null;
      ps_select.setInt(1, idu);
      ResultSet rs = ps_select.executeQuery();

      if(rs.next()){
      		String nom = rs.getString("nom");
      		String role = rs.getString("role");
          u = new Utilisateur(idu,nom,role);        
      }

      return u;
  }

  public int insertUtilisateur(Utilisateur p) throws Exception{
	  int clef = -1;
      ps_insert.setString(1,p.getNom());
      ps_insert.setString(2,p.getRole());
      ps_insert.executeUpdate();
      
      ResultSet clefs = ps_insert.getGeneratedKeys();

      if (clefs.next()){
          clef = clefs.getInt(1);
      }
      return clef;
  }
        
  public void updateUtilisateur(Utilisateur p) throws Exception{
			ps_update.setString(1, p.getNom());
			ps_update.setString(2, p.getRole());
			ps_update.setInt(3, p.getIdu());
			ps_update.executeUpdate();
  }

  public void deleteUtilisateur(int idu) throws Exception{
	   ps_delete.setInt(1,idu);
		 ps_delete.executeUpdate();
  }

  private ArrayList<Utilisateur> getUtilisateurs(String req) throws Exception{
        Utilisateur util;
	      ArrayList<Utilisateur> arrutil = null;

		    arrutil = new ArrayList<Utilisateur>(); 
		    Statement st = conn.createStatement(); 
		    ResultSet rs = st.executeQuery(req); 

    		while(rs.next()){ 
    		    util = new Utilisateur(rs.getInt("idu"), rs.getString("nom"), rs.getString("role")); 
    		    arrutil.add(util); 
    		} 
	      return arrutil;
  }

  public ArrayList<Utilisateur> getUtilisateurs() throws Exception{
	   return getUtilisateurs("select * from utilisateur order by idu");
  }

  public ArrayList<Utilisateur> getUtilisateursTri(String tri) throws Exception{
	   return getUtilisateurs("select * from utilisateur order by " + tri);
  }
}
