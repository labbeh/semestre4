package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_CONNEXION;
import beans.Connexion;

public class CommandeConnexionsServeur implements Commande{
  private final String next;

  public CommandeConnexionsServeur(String next) {
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_CONNEXION dbConnexion = dbGlobal.getDB_CONNEXION();
	int ids = Integer.parseInt(req.getParameter("ids"));
	List<Connexion> connexions = null;

	/* Retourne l'ensemble des connexions pour un serveur avec une id (ids) */

	try{
		connexions = dbConnexion.getConnexionsServeur(ids);
	}

	catch(Exception e){
		System.out.println(e);
	}
	
	req.setAttribute("connexions", connexions);
    return next;
  }

}
