package beans;

import java.util.*;
import java.sql.Timestamp;

public class ConnexionUtilisateurServeur extends Connexion{
	String nomU;
	String nomS;

	public String getNomU(){return nomU;} 
	public String getNomS(){return nomS;} 
	
	public void setNomU(String nomU){this.nomU=nomU;} 
	public void setNomS(String nomS){this.nomS=nomS;} 
	
	public ConnexionUtilisateurServeur(int idu , int ids, Timestamp datec, String login, int duree, String nomU, String nomS){
		super(idu,ids,datec,login,duree);
		this.setNomU(nomU);
		setNomS(nomS);
	}
	
	public ConnexionUtilisateurServeur(Timestamp datec, String login, int duree, String nomU, String nomS){
		super(datec,login,duree);
		this.setNomS(nomS);
		this.setNomU(nomU);
	}
	
	public ConnexionUtilisateurServeur(String login, int duree, String nomU, String nomS){
		super(login,duree);
		this.setNomS(nomS);
		this.setNomU(nomU);
	}
	
	public String toString(){
		return super.toString();
	} 
}

