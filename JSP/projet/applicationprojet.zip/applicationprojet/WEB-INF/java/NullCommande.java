package cmd;

import javax.servlet.*;
import javax.servlet.http.*;

public class NullCommande implements Commande{
  private String next;

  public NullCommande(String next) {
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
    return next;
  }
}

