package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DBS;
import bdd.DB_CONNEXION;
import beans.Connexion;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.sql.*;
import java.util.Date;


public class CommandeModifierConnexionValider implements Commande {
  private final String next;

  public CommandeModifierConnexionValider(String next) {
  	this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_CONNEXION dbConnexion = dbGlobal.getDB_CONNEXION();
	List<Connexion> connexions = null;

	/* On modifie la connexion en fonction des informations du formulaire, soit le login et la duree */
	try{
		int idu = Integer.parseInt(req.getParameter("idu")); 
		int ids = Integer.parseInt(req.getParameter("ids"));
		String login = req.getParameter("login");
		int duree = Integer.parseInt(req.getParameter("duree"));
		
		Connexion connexion = new Connexion(idu, ids, login, duree);
		dbConnexion.updateConnexion(connexion);
	}

	catch(Exception e){
		System.out.println(e);
	}

	try{
		connexions = dbConnexion.getConnexions();
	}

	catch(Exception e){
		System.out.println(e);
	}

	req.setAttribute("connexions", connexions);
    return next;
  }
}
