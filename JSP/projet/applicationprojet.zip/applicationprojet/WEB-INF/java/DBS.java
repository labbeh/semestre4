/* Class donnée par l'enseignant pour la connexion */

package bdd;
import java.sql.*;

public class DBS{

  private static DBS instance;

  private Connection cnx;
  private DB_UTILISATEUR db_utilisateur;
  private DB_SERVEUR db_serveur;
  private DB_CONNEXION db_connexion;
  


  public static DBS getInstance(){
	   if (null == instance){
      instance=new DBS();
    }

	  return instance;
  }

  
  private DBS(){
     String urlServeur = "jdbc:postgresql://woody/dn170747"; 
     String login = "dn170747"; 
     String mdp = "0410"; 

     try{
        Class.forName ("org.postgresql.Driver");
		    System.out.println("Driver installe");
        cnx = DriverManager.getConnection (urlServeur,login,mdp);
		    System.out.println("connexion etablie");
		    db_utilisateur = new DB_UTILISATEUR(cnx);
		    db_serveur = new DB_SERVEUR(cnx);
		    db_connexion = new DB_CONNEXION(cnx);
     }

     catch(ClassNotFoundException e){
        System.out.println(e);
     }

     catch(SQLException e){
      System.out.println(e);
    }
  }

  public DB_UTILISATEUR getDB_UTILISATEUR(){return db_utilisateur;}
  public DB_SERVEUR getDB_SERVEUR(){return db_serveur;}
  public DB_CONNEXION getDB_CONNEXION(){return db_connexion;}
}

