/* Class qui reprend le modèle de Utilisateur */

package beans;

import java.util.*;
import java.sql.Timestamp;

public class Connexion{
	private int idu;
	private int ids;
    private Timestamp datec;
    private String login;
	private int duree;

	public int getIdu(){return idu;}
   	public int getIds(){return ids;}
    public Timestamp getDatec(){return datec;}
    public String getLogin(){return login;}
	public int getDuree(){return duree;}
    
    public void setIdu(int idu){this.idu = idu;}
    public void setIds(int ids){this.ids = ids;}
    public void setDatec(Timestamp datec){this.datec = datec;}
	public void setLogin(String login ){this.login = login;}
    public void setDuree(int duree){this.duree = duree;}
        
	public Connexion(int idu, int ids, Timestamp datec, String login, int duree){
		this.setIdu(idu);
		this.setIds(ids);
		this.setDatec(datec);
		this.setLogin(login);
		this.setDuree(duree);
    }
    
    public Connexion(int idu, Timestamp datec, String login, int duree){
		this.setIdu(idu);
		this.setIds(-1);
		this.setDatec(datec);
		this.setLogin(login);
		this.setDuree(duree);
    }
    
    public Connexion(Timestamp datec, int ids, String login, int duree){
		this.setIdu(-1);
		this.setIds(ids);
		this.setDatec(datec);
		this.setLogin(login);
		this.setDuree(duree);
    }
    
    public Connexion(Timestamp datec, String login, int duree){
		this.setIdu(-1);
		this.setIds(-1);
		this.setDatec(datec);
		this.setLogin(login);
		this.setDuree(duree);
    }
	
	public Connexion(String login, int duree){
		this.setIdu(-1);
		this.setIds(-1);
		this.setDatec(null);
		this.setLogin(login);
		this.setDuree(duree);
    }

	public String toString(){
   		return idu+ "," + ids + "," + datec + "," + login + "," + duree;
	}
}

