/* Class un peu plus complexe puisqu'une connexion possède une id de serveur et d'utilisateur */

package bdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Date;
import java.util.*;

import beans.Connexion;
import beans.ConnexionUS;

public class DB_CONNEXION{

  Connection conn;

  PreparedStatement ps_select;
  PreparedStatement ps_update;

  PreparedStatement ps_deleteServeur;
  PreparedStatement ps_deleteConnexionUtilisateur;
  PreparedStatement ps_delete;

  PreparedStatement ps_select_connexionsServeur;
  PreparedStatement ps_select_connexionUtilisateurs;
  PreparedStatement ps_select_connexionDateServeur;
  
  public DB_CONNEXION(Connection conn){

     this.conn = conn;
     try{
        /* On prépare les requêtes */
        ps_select = conn.prepareStatement("select datec, login, duree from connexion where idu = ? and ids = ? and datec = ?");
  		  ps_select_connexionsServeur = conn.prepareStatement("select datec, login, duree from connexion where ids = ?");
  		  ps_select_connexionUtilisateurs = conn.prepareStatement("select s.nom, c.datec, c.login, c.duree from connexion c, serveur s where c.idu = ? and c.ids = s.ids");
		    ps_select_connexionDateServeur = conn.prepareStatement("select u.nom, c.login, c.duree from connexion c, utilisateur u where c.datec >= ? and c.datec < ? and c.ids = ? and c.idu = u.idu");
        
        ps_update = conn.prepareStatement("update connexion set login = ?, duree = ? where ids=? and idu=?");
       

        ps_deleteServeur = conn.prepareStatement("delete from connexion where ids = ?"); 
		    ps_deleteConnexionUtilisateur = conn.prepareStatement("delete from connexion where idu=?"); 
		    ps_delete = conn.prepareStatement("delete from connexion where idu = ? and ids = ? and datec = ?");
     } 

     catch(SQLException ex){
      System.out.println(ex);
    }
  }
      
  /* On recupère une connexion en fonction de l'id d'un utilisateur, serveur et d'une dare */
  public Connexion getConnexion(int idu, int ids, Timestamp datec) throws Exception{

      Connexion c = null;
      ps_select.setInt(1,idu);
      ps_select.setInt(2,ids);
      ps_select.setTimestamp(3, datec);
      ResultSet rs = ps_select.executeQuery();

      if(rs.next()){
      	  Timestamp t = rs.getTimestamp("datec");
		      String login = rs.getString("login");
		      int duree = rs.getInt("duree");
          c = new Connexion(idu, ids, t, login, duree);        
      }
      return c;
  }
  
  /* Ensemble des connexions retournés en fonction de l'id du serveur sous une AL */
  public ArrayList<Connexion> getConnexionsServeur(int ids) throws Exception{

      Connexion c;
      ArrayList<Connexion> arrconnexion = new ArrayList<Connexion>();
      ps_select_connexionsServeur.setInt(1,ids);
      ResultSet rs = ps_select_connexionsServeur.executeQuery();

      while(rs.next()){
    		  Timestamp datec = rs.getTimestamp("datec");
    		  String login = rs.getString("login");
    		  int duree = rs.getInt("duree");
          c = new Connexion(datec, login, duree);     
          arrconnexion.add(c);   
      }
      return arrconnexion;
  }
  
  /* Ensemble des connexions retournés en fonction de l'id de l'utilisateur sous une AL */
  public ArrayList<ConnexionUS> getConnexionsUtilisateur(int idu) throws Exception{

      ConnexionUS c;
      ArrayList<ConnexionUS> arrconnexion = new ArrayList<ConnexionUS>();
      ps_select_connexionUtilisateurs.setInt(1, idu);
      ResultSet rs = ps_select_connexionUtilisateurs.executeQuery();

      while(rs.next()){
		      String nomU = "";
      	  String nomS = rs.getString("nom");
		      Timestamp datec = rs.getTimestamp("datec");
		      String login = rs.getString("login");
		      int duree = rs.getInt("duree");
          c = new ConnexionUS(datec, login, duree, nomU, nomS);   
          arrconnexion.add(c);     
      }

      return arrconnexion;
  }
  
  /* Ensemble des connexions retournés en fonction de l'id du serveur sous une AL */
  public ArrayList<ConnexionUS> getConnexionsDateServeur(int ids, Timestamp datecMin, Timestamp datecMax) throws Exception{

      ConnexionUS c;
      ArrayList<ConnexionUS> arrconnexion = new ArrayList<ConnexionUS>();

	    ps_select_connexionDateServeur.setTimestamp(1, datecMin);
	    ps_select_connexionDateServeur.setTimestamp(2, datecMax);
      ps_select_connexionDateServeur.setInt(3, ids);

      ResultSet rs = ps_select_connexionDateServeur.executeQuery();

      while(rs.next()){
  		  String nomU = rs.getString("nom");
  		  String nomS = "";
  		  String login = rs.getString("login");
  		  int duree = rs.getInt("duree");
        c = new ConnexionUS(login, duree, nomU, nomS);     
        arrconnexion.add(c);
      }

      return arrconnexion;
  }
        
  /* Modifier une connexion */
  public void updateConnexion(Connexion c) throws Exception{
			ps_update.setString(1,c.getLogin());
			ps_update.setInt(2,c.getDuree());
			ps_update.setInt(3,c.getIds());
			ps_update.setInt(4,c.getIdu());
			ps_update.executeUpdate();
  }

  /* Supprimer une connexion en fonction d'une id de serveur */
  public void deleteConnexionServeur(int ids) throws Exception{
	   ps_deleteServeur.setInt(1, ids);
	   ps_deleteServeur.executeUpdate();
  }
  
  /* Supprimer une connexion en fonction d'une id utilisateur, serveur et la date */
  public void deleteConnexion(int idu, int ids, Timestamp datec) throws Exception{
    	ps_delete.setInt(1, idu);
    	ps_delete.setInt(2, ids);
    	ps_delete.setTimestamp(3, datec);
    	ps_delete.executeUpdate();
  }
  
  /* Supprimer une connexion à l'utilisateur en fonction d'un id utilisateur */
  public void deleteConnexionUtilisateur(int idu) throws Exception{
	   ps_deleteConnexionUtilisateur.setInt(1, idu);
	   ps_deleteConnexionUtilisateur.executeUpdate();
  }


  /* Comme pour le serveur et utilisateur, on retourne l'ensemble des connexions dans un AL */
  private ArrayList<Connexion> getConnexions(String req) throws Exception{
      Connexion connex;
	    ArrayList<Connexion> arrconnexion = null;

		  arrconnexion = new ArrayList<Connexion>(); 
		  Statement st = conn.createStatement(); 
		  ResultSet rs = st.executeQuery(req); 

		  while(rs.next()){ 
		      connex = new Connexion(rs.getInt("idu"), rs.getInt("ids"), rs.getTimestamp("datec"), rs.getString("login"), rs.getInt("duree")); 
		      arrconnexion.add(connex); 
		  }
	    return arrconnexion;
  }
  
  /* Comme pour le serveur et utilisateur, on retourne l'ensemble des connexions dans un AL */
  public ArrayList<Connexion> getConnexions() throws Exception{
	   return getConnexions("SELECT * FROM connexion");
  }
  
  /* Comme pour le serveur et utilisateur, on retourne l'ensemble des connexions dans un AL */
  private ArrayList<ConnexionUS> getConnexionsUS(String req) throws Exception{

        ConnexionUS connex;
		    ArrayList<ConnexionUS> arrconnexion = null;

		    arrconnexion = new ArrayList<ConnexionUS>(); 
		    Statement st = conn.createStatement(); 
		    ResultSet rs = st.executeQuery(req); 
        
		    while(rs.next()){ 
		      connex = new ConnexionUS(rs.getInt("idu"), rs.getInt("ids"), rs.getTimestamp("datec"), rs.getString("login"), rs.getInt("duree"), rs.getString(6), rs.getString(7) ); 
		      arrconnexion.add(connex); 
	 	    } 
	     return arrconnexion;
  }
  
  /* Comme pour le serveur et utilisateur, on retourne l'ensemble des connexions dans un AL */
  public ArrayList<ConnexionUS> getConnexionsUS() throws Exception{
	   return getConnexionsUS("select c.idu, c.ids, c.datec, c.login, c.duree, u.nom, s.nom from connexion c, utilisateur u, serveur s where u.idu = c.idu and s.ids = c.ids order by s.nom,u.nom");
  }
}
