package cmd;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bdd.DB_CONNEXION;
import bdd.DBS;
import beans.Connexion;

public class CommandeConnexions implements Commande {
  private final String next;

  public CommandeConnexions(String next) {
        this.next = next;
  }

  public String execute(HttpServletRequest req) throws Exception {
	DBS dbGlobal = DBS.getInstance();
	DB_CONNEXION dbConnexion = dbGlobal.getDB_CONNEXION();
	List<Connexion> connexions = null;

	/* Retourne toutes les connexions */
	try{
		connexions = dbConnexion.getConnexions();
	}

	catch(Exception e){
		System.out.println(e);
	}
	
	req.setAttribute("connexions", connexions);
    return next;
  }

}
