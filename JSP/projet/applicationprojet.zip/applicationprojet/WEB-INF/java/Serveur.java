/* Class serveur qui reprend la class Utilisateur mais adaptée pour la BDD du serveur */

package beans;

import java.util.*;

public class Serveur{
	private int ids;
    private String nom;
    private String os;

   	public int getIds(){return ids;}
    public String getNom(){return nom;}
    public String getOS(){return os;}
    
    public void setIds(int ids){ this.ids = ids;}
    public void setNom(String nom){this.nom = nom;}
    public void setOS (String os){ this.os = os;}
        
	public Serveur(int ids, String nom, String os){
		this.setIds(ids);
		this.setNom(nom);
	    this.setOS(os);
    }

	public Serveur(String nom, String os){
	    this.setIds(-1);
	    this.setNom(nom);
	    this.setOS(os);
   	}

	public String toString(){
   		return ids + "," + nom + "," + os;
	}
}

