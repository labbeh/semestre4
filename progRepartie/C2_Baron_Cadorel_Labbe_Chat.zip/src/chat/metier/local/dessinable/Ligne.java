package chat.metier.local.dessinable;

public class Ligne implements IDessinable {

	@Override
	public String getType() {
		return "ligne";
	}

}
