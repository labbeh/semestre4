package chat.ihm.panels.dessin;

public interface IDessinable {
	public abstract String getType();
}
