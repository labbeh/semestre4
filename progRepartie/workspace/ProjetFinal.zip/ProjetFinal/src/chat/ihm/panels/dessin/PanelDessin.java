package chat.ihm.panels.dessin;

import java.awt.Graphics;
import java.awt.LayoutManager;

import javax.swing.JPanel;

public class PanelDessin extends JPanel {

	public PanelDessin() {
		
	}
	
	/**
	 * Zone de dessin
	 * */
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
	}
	
	

}
