package chat;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Controleur();

	}

}
