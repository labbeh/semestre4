package chat.metier.local.dessinable;

public interface IDessinable {
	public abstract String getType();
}
